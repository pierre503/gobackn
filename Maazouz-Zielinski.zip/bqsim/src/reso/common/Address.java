package reso.common;

public interface Address {

	int getByteLength();
	
}
